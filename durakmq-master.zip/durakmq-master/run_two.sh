#!/usr/bin/env sh
x=50 python main.py &
x=550 python main.py